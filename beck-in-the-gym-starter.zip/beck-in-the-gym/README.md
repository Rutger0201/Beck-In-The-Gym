# Beck In The Gym

Professionele personal-trainingwebsite voor **Beck In The Gym**.

## Doel

Een premium, toegankelijke website met een donker, licht leesbaar design. De website richt zich op beginners en mensen die sterker, fitter en gezonder willen worden, met nadruk op spieropbouw en krachttraining.

## Richtlijnen

- **Geen prijzen** op de website.
- **Geen boekingen of reserveringen** via de website.
- Bezoekers kunnen contact opnemen via een **contactformulier**.
- Modern donker thema, met voldoende contrast en heldere fitnessfotografie.
- Mobielvriendelijk, snel en toegankelijk.
- Geen verzonnen reviews, certificeringen of resultaten.

## Voorgestelde pagina's

| Pagina | Inhoud |
| --- | --- |
| Home | Introductie, sterke fotografie, aanpak, contactoproep |
| Over mij | Trainer, ervaring, visie en werkwijze |
| Personal training | Begeleiding, voor wie, wat je kunt verwachten |
| Trainingsdoelen | Spieropbouw, kracht, fitter worden, gezondheid |
| Contact | Contactformulier en contactinformatie |
| Privacy | Privacyverklaring, met aandacht voor contactformulier |

## Projectstructuur

```text
beck-in-the-gym/
├── public/
│   └── images/             # Geoptimaliseerde eigen foto's en visuals
├── src/
│   ├── components/         # Herbruikbare interfaceonderdelen
│   ├── pages/              # Pagina's / routes
│   ├── styles/             # Kleuren, typografie en globale styling
│   └── lib/                # Helpers, validatie en formulierlogica
├── docs/
│   ├── content.md          # Tekstrichtlijnen en paginaplan
│   └── design.md           # Visuele richtlijnen
├── .env.example            # Voorbeeld van omgevingsvariabelen
├── .gitignore
└── README.md
```

Dit is een **framework-onafhankelijke basis**: de map bevat nog geen werkende website of geconfigureerd contactformulier. Kies daarna bijvoorbeeld Next.js of Astro en pas de structuur aan de conventies van dat framework aan.

## Contactformulier

Vereiste velden: naam, e-mailadres en bericht. Voeg server-side validatie, spambeveiliging en een duidelijke privacyverklaring toe. Plaats API-sleutels uitsluitend in niet-gecommitte omgevingsvariabelen. Publiceer geen echte contactgegevens zonder toestemming.

## Volgende stappen

1. Maak op GitHub een **private** repository `beck-in-the-gym` aan.
2. Upload of push de inhoud van dit starterpakket.
3. Kies een technische stack (bijvoorbeeld Astro voor een snelle informatieve site).
4. Bouw de pagina's, het contactformulier en de responsive navigatie.
5. Voeg geoptimaliseerde foto's toe en controleer contrast, toegankelijkheid en privacy.

## Git gebruiken

```bash
git init
git branch -M main
git add .
git commit -m "Initial project structure"
git remote add origin https://github.com/JE-GEBRUIKERSNAAM/beck-in-the-gym.git
git push -u origin main
```

Vervang `JE-GEBRUIKERSNAAM` met je eigen GitHub-gebruikersnaam. Als je de repository op GitHub al met een README hebt geïnitialiseerd, stem eerst de bestaande commitgeschiedenis af voordat je pusht.
