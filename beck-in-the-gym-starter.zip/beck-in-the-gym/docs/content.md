# Contentplan

## Doelgroep
Beginners en sporters die werken aan spieropbouw, kracht, conditie en algemene gezondheid.

## Tone of voice
Direct, motiverend, professioneel en begrijpelijk. Geen overdreven beloftes.

## Home
- Hero: persoonlijke begeleiding gericht op sterker en fitter worden
- Intro over Beck In The Gym
- Vier trainingsdoelen
- Uitleg van de aanpak
- CTA: Neem contact op

## Over mij
- Wie ben ik?
- Ervaring en werkwijze
- Waarom ik personal training geef

## Personal training
- Voor wie?
- Hoe werkt begeleiding?
- Focus op techniek, progressie en persoonlijke doelen
- CTA: Stel je vraag

## Contact
- Naam, e-mailadres en bericht
- Duidelijke bevestiging en foutmeldingen
- Link naar privacyverklaring

## Niet toevoegen
- Prijstabellen
- Boekingskalender
- Niet-geverifieerde testimonials of kwalificaties
