# Visuele stijl

- Basis: donker antraciet / near-black, geen volledig zwart als standaardvlak.
- Gebruik wit of lichtgrijs voor leesbare teksten en één herkenbare accentkleur.
- Foto's mogen duidelijk en levendig blijven; maak ze niet standaard extreem donker.
- Gebruik een subtiele donkere gradient-overlay **alleen** waar tekst over de foto staat.
- Zorg voor goede kleurcontrasten, duidelijke focus-states en rustig bewegende animaties.
- Gebruik eigen, rechtmatig verkregen foto's; comprimeer en exporteer in WebP/AVIF.
- Gebruik responsive afbeeldingsformaten en betekenisvolle alt-teksten.
- Vermijd overdadige effecten en zware videobestanden.
